from __future__ import annotations

import heapq
from typing import Literal, TypedDict


ErrorName = Literal[
    "BlankStepName",
    "DuplicateStep",
    "UnknownDependency",
    "SelfDependency",
    "Cycle",
]


class Step(TypedDict):
    name: str
    needs: list[str]


class Pipeline(TypedDict):
    steps: list[Step]


class OrderSuccess(TypedDict):
    ok: list[str]


class ErrorResult(TypedDict):
    error: ErrorName


class PlannedSteps(TypedDict):
    ordered_steps: list[str]


class PlanSuccess(TypedDict):
    ok: PlannedSteps


OrderResult = OrderSuccess | ErrorResult
PlanResult = PlanSuccess | ErrorResult


def topologically_order_steps(steps: list[Step]) -> OrderResult:
    names = [step["name"] for step in steps]

    if any(name.strip() == "" for name in names):
        return {"error": "BlankStepName"}

    name_set = set(names)
    if len(name_set) != len(names):
        return {"error": "DuplicateStep"}

    needs_by_name = {step["name"]: set(step["needs"]) for step in steps}

    if any(
        dependency not in name_set
        for dependencies in needs_by_name.values()
        for dependency in dependencies
    ):
        return {"error": "UnknownDependency"}

    if any(name in dependencies for name, dependencies in needs_by_name.items()):
        return {"error": "SelfDependency"}

    remaining_needs = {
        name: len(dependencies) for name, dependencies in needs_by_name.items()
    }
    dependents: dict[str, set[str]] = {name: set() for name in names}
    for name, dependencies in needs_by_name.items():
        for dependency in dependencies:
            dependents[dependency].add(name)

    ready = [name for name, count in remaining_needs.items() if count == 0]
    heapq.heapify(ready)
    ordered: list[str] = []

    while ready:
        name = heapq.heappop(ready)
        ordered.append(name)
        for dependent in dependents[name]:
            remaining_needs[dependent] -= 1
            if remaining_needs[dependent] == 0:
                heapq.heappush(ready, dependent)

    if len(ordered) != len(names):
        return {"error": "Cycle"}

    return {"ok": ordered}


def plan_pipeline(pipeline: Pipeline) -> PlanResult:
    result = topologically_order_steps(pipeline["steps"])
    if "error" in result:
        return result
    return {"ok": {"ordered_steps": result["ok"]}}
