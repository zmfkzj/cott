from heapq import heapify, heappop, heappush

from cott_runtime import CottList, Err, Ok, Result
from curriculum.artifact_pipeline_types import (
    ArtifactPipelineError,
    ArtifactPipelineError_BlankStepName,
    ArtifactPipelineError_Cycle,
    ArtifactPipelineError_DuplicateStep,
    ArtifactPipelineError_SelfDependency,
    ArtifactPipelineError_UnknownDependency,
    BuildStep,
)


def topologically_order_steps(steps: CottList[BuildStep]) -> Result[CottList[str], ArtifactPipelineError]:
    for step in steps:
        if step.name.strip() == "":
            return Err(error=ArtifactPipelineError_BlankStepName())

    names: set[str] = set()
    for step in steps:
        if step.name in names:
            return Err(error=ArtifactPipelineError_DuplicateStep())
        names.add(step.name)

    for step in steps:
        for need in step.needs:
            if need not in names:
                return Err(error=ArtifactPipelineError_UnknownDependency())

    for step in steps:
        if step.name in step.needs:
            return Err(error=ArtifactPipelineError_SelfDependency())

    remaining_needs: dict[str, int] = {}
    dependents: dict[str, list[str]] = {name: [] for name in names}
    ready: list[str] = []
    for step in steps:
        need_count = len(step.needs)
        remaining_needs[step.name] = need_count
        if need_count == 0:
            ready.append(step.name)
        for need in step.needs:
            dependents[need].append(step.name)
    heapify(ready)

    ordered_steps: list[str] = []
    while ready:
        name = heappop(ready)
        ordered_steps.append(name)
        for dependent in dependents[name]:
            need_count = remaining_needs[dependent] - 1
            remaining_needs[dependent] = need_count
            if need_count == 0:
                heappush(ready, dependent)

    if len(ordered_steps) != len(steps):
        return Err(error=ArtifactPipelineError_Cycle())
    return Ok(value=CottList(values=ordered_steps))
