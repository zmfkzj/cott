from __future__ import annotations

import heapq
from typing import Literal, TypeAlias, TypedDict


ErrorName: TypeAlias = Literal[
    "BlankStepName",
    "DuplicateStep",
    "UnknownDependency",
    "SelfDependency",
    "Cycle",
]


class Step(TypedDict):
    name: str
    needs: list[str]


class Pipeline(TypedDict):
    steps: list[Step]


class _OrderSuccess(TypedDict):
    ok: list[str]


class _Plan(TypedDict):
    ordered_steps: list[str]


class _PlanSuccess(TypedDict):
    ok: _Plan


class _Failure(TypedDict):
    error: ErrorName


OrderResult: TypeAlias = _OrderSuccess | _Failure
PlanResult: TypeAlias = _PlanSuccess | _Failure


def topologically_order_steps(steps: list[Step]) -> OrderResult:
    names = [step["name"] for step in steps]

    if any(name.strip() == "" for name in names):
        return {"error": "BlankStepName"}
    if len(set(names)) != len(names):
        return {"error": "DuplicateStep"}

    known_names = set(names)
    dependencies = {
        step["name"]: set(step["needs"])
        for step in steps
    }

    if any(
        dependency not in known_names
        for needs in dependencies.values()
        for dependency in needs
    ):
        return {"error": "UnknownDependency"}
    if any(name in needs for name, needs in dependencies.items()):
        return {"error": "SelfDependency"}

    remaining_needs = {
        name: len(needs)
        for name, needs in dependencies.items()
    }
    dependents: dict[str, set[str]] = {name: set() for name in names}
    for name, needs in dependencies.items():
        for dependency in needs:
            dependents[dependency].add(name)

    ready = [name for name, count in remaining_needs.items() if count == 0]
    heapq.heapify(ready)
    ordered: list[str] = []

    while ready:
        name = heapq.heappop(ready)
        ordered.append(name)
        for dependent in dependents[name]:
            remaining_needs[dependent] -= 1
            if remaining_needs[dependent] == 0:
                heapq.heappush(ready, dependent)

    if len(ordered) != len(names):
        return {"error": "Cycle"}
    return {"ok": ordered}


def plan_pipeline(pipeline: Pipeline) -> PlanResult:
    result = topologically_order_steps(pipeline["steps"])
    if "error" in result:
        return {"error": result["error"]}
    return {"ok": {"ordered_steps": result["ok"]}}
