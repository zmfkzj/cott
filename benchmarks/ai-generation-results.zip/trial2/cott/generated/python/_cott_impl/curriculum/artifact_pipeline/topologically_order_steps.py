from heapq import heappop, heappush

from cott_runtime import CottList, Err, Ok, Result
from curriculum.artifact_pipeline_types import (
    ArtifactPipelineError,
    ArtifactPipelineError_BlankStepName,
    ArtifactPipelineError_Cycle,
    ArtifactPipelineError_DuplicateStep,
    ArtifactPipelineError_SelfDependency,
    ArtifactPipelineError_UnknownDependency,
    BuildStep,
)


def topologically_order_steps(steps: CottList[BuildStep]) -> Result[CottList[str], ArtifactPipelineError]:
    for step in steps:
        if step.name.strip() == "":
            return Err(error=ArtifactPipelineError_BlankStepName())

    names: set[str] = set()
    for step in steps:
        if step.name in names:
            return Err(error=ArtifactPipelineError_DuplicateStep())
        names.add(step.name)

    for step in steps:
        for dependency in step.needs:
            if dependency not in names:
                return Err(error=ArtifactPipelineError_UnknownDependency())

    for step in steps:
        if step.name in step.needs:
            return Err(error=ArtifactPipelineError_SelfDependency())

    remaining_needs: dict[str, int] = {}
    dependents: dict[str, list[str]] = {name: [] for name in names}
    ready: list[str] = []
    for step in steps:
        remaining_needs[step.name] = len(step.needs)
        if len(step.needs) == 0:
            heappush(ready, step.name)
        for dependency in step.needs:
            dependents[dependency].append(step.name)

    ordered: list[str] = []
    while ready:
        name = heappop(ready)
        ordered.append(name)
        for dependent in dependents[name]:
            remaining_needs[dependent] -= 1
            if remaining_needs[dependent] == 0:
                heappush(ready, dependent)

    if len(ordered) != len(steps):
        return Err(error=ArtifactPipelineError_Cycle())
    return Ok(value=CottList(values=ordered))
