from heapq import heapify, heappop, heappush

from cott_runtime import CottList, Err, Ok, Result
from curriculum.artifact_pipeline_types import (
    ArtifactPipelineError,
    ArtifactPipelineError_BlankStepName,
    ArtifactPipelineError_Cycle,
    ArtifactPipelineError_DuplicateStep,
    ArtifactPipelineError_SelfDependency,
    ArtifactPipelineError_UnknownDependency,
    BuildStep,
)


def topologically_order_steps(steps: CottList[BuildStep]) -> Result[CottList[str], ArtifactPipelineError]:
    names: set[str] = set()
    duplicate_found = False
    for step in steps:
        if step.name.strip() == "":
            return Err(error=ArtifactPipelineError_BlankStepName())
        if step.name in names:
            duplicate_found = True
        names.add(step.name)
    if duplicate_found:
        return Err(error=ArtifactPipelineError_DuplicateStep())

    self_dependency_found = False
    for step in steps:
        for need in step.needs:
            if need not in names:
                return Err(error=ArtifactPipelineError_UnknownDependency())
            if need == step.name:
                self_dependency_found = True
    if self_dependency_found:
        return Err(error=ArtifactPipelineError_SelfDependency())

    dependents: dict[str, list[str]] = {name: [] for name in names}
    remaining_needs: dict[str, int] = {}
    for step in steps:
        remaining_needs[step.name] = len(step.needs)
        for need in step.needs:
            dependents[need].append(step.name)

    ready: list[str] = [name for name in names if remaining_needs[name] == 0]
    heapify(ready)
    ordered: list[str] = []
    while ready:
        name = heappop(ready)
        ordered.append(name)
        for dependent in dependents[name]:
            remaining_needs[dependent] -= 1
            if remaining_needs[dependent] == 0:
                heappush(ready, dependent)

    if len(ordered) != len(names):
        return Err(error=ArtifactPipelineError_Cycle())
    return Ok(value=CottList(values=ordered))
