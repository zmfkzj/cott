from __future__ import annotations

import heapq
from typing import Literal, TypedDict


ErrorName = Literal[
    "BlankStepName",
    "DuplicateStep",
    "UnknownDependency",
    "SelfDependency",
    "Cycle",
]


class Step(TypedDict):
    name: str
    needs: list[str]


class Pipeline(TypedDict):
    steps: list[Step]


class _OrderSuccess(TypedDict):
    ok: list[str]


class _Plan(TypedDict):
    ordered_steps: list[str]


class _PlanSuccess(TypedDict):
    ok: _Plan


class _Failure(TypedDict):
    error: ErrorName


OrderResult = _OrderSuccess | _Failure
PlanResult = _PlanSuccess | _Failure


def topologically_order_steps(steps: list[Step]) -> OrderResult:
    if any(step["name"].strip() == "" for step in steps):
        return {"error": "BlankStepName"}

    names: set[str] = set()
    for step in steps:
        name = step["name"]
        if name in names:
            return {"error": "DuplicateStep"}
        names.add(name)

    dependencies = {step["name"]: set(step["needs"]) for step in steps}

    if any(
        dependency not in names
        for needs in dependencies.values()
        for dependency in needs
    ):
        return {"error": "UnknownDependency"}

    if any(name in needs for name, needs in dependencies.items()):
        return {"error": "SelfDependency"}

    dependents: dict[str, list[str]] = {name: [] for name in names}
    remaining_needs: dict[str, int] = {}
    for name, needs in dependencies.items():
        remaining_needs[name] = len(needs)
        for dependency in needs:
            dependents[dependency].append(name)

    ready = [name for name, count in remaining_needs.items() if count == 0]
    heapq.heapify(ready)
    ordered: list[str] = []

    while ready:
        name = heapq.heappop(ready)
        ordered.append(name)
        for dependent in dependents[name]:
            remaining_needs[dependent] -= 1
            if remaining_needs[dependent] == 0:
                heapq.heappush(ready, dependent)

    if len(ordered) != len(names):
        return {"error": "Cycle"}
    return {"ok": ordered}


def plan_pipeline(pipeline: Pipeline) -> PlanResult:
    result = topologically_order_steps(pipeline["steps"])
    if "error" in result:
        return result
    return {"ok": {"ordered_steps": result["ok"]}}
